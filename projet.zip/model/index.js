export { default } from "./meal";
