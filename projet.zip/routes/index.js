import Router from "koa-router"
import { SearchRoutes } from "./search.js";

export const router = new Router();

router.get('/hello', (ctx) => { ctx.body = "Hello" },)

router.use(SearchRoutes())

export function MainRouter() {
    return router.routes()
}