import Router from 'koa-router'
import GraphDB from '../database/graphdb.js'
import Solr from '../database/solr.js'
const _ = new Router()

_.prefix("/search")


_.get('/hello', async (ctx) => {
    var main
    let response = await GraphDB.query("SELECT * WHERE {?a rdfs:subClassOf ?b}")
    var query = Solr.query().q("object:fruit or subject:fruit")
    response = await Solr.search(query)
    const filter = response.response.docs.filter(x=>x.link[0].endsWith("type")&&x.subject[0].endsWith("Class"))
    if(filter.length){
       
        main = await GraphDB.query(`SELECT * WHERE {<${filter[0].object[0]}> ?link ?object}`)
        main = main.results.bindings
    }
    ctx.body= {main, filter}
})



_.get('/', async(ctx) => {
    if(!ctx.query.query){
        return ctx.render("index")
    }
  
    var main
    const term = ctx.query.query
    var query = Solr.query().q(`object:${term} or subject:${term}`)
    let response = await Solr.search(query)

    //Tout ce qui est link.endwith=>Label est un objet ou une instance
    //On prend son label (subject) on met comme resultat puis on recherche sa description
    //On utilise l'objet (object) et on fait une SPARQL pour avoir les infos sur l'objets



    const filter = response.response.docs.filter(x=>x.link[0].endsWith("type")&&x.subject[0].endsWith("Class"))
    if(filter.length){
       
        main = await GraphDB.query(`SELECT * WHERE {<${filter[0].object[0]}> ?link ?object}`)
        main = main.results.bindings
    }
   // return ctx.body = ({main, filter, response: response.response.docs, query});
   //return ctx.render('wiki',{main, filter, response})
   return ctx.render('results',{main, filter, response})

})


export function SearchRoutes() {
    return _.routes();
}
